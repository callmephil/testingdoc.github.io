# Looks

In this chapter, we'll learn to make things look ok.

We will not learn to *design*, that's another course entirely.