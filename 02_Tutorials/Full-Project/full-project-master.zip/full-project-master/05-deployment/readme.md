# Deployment

A lot of little details lie here to make an application ready for prime time

Organizing Code better
1. Put sensitive variables in environment files
1. Use http verbs
1. Enabling https
1. Switching options for the production build
1. Uploading to a server
1. Setting up Git hooks
1. Installing Nginx and enabling it
1. getting errors and crashes notifications
1.  Using `Forever`